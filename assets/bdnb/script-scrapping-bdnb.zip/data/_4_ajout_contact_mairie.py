''' faire tourner contacts\public.py d'abord '''

import os
import pandas as pd

path_public = r'/home/alexis/git/BDNB/AnnuairePublic'
admin_annuaire = pd.read_csv(os.path.join(path_public, "contact_admin.csv"))
admin_annuaire.loc[:, 'siren'] = admin_annuaire['siren'].fillna(-1).astype(int).astype(str)

def add_contact_admin(df):
    """
    Ajoute les informations de contact administratif à un DataFrame.
    
    :param df: DataFrame contenant les données des contacts.
    :return: DataFrame avec les informations de contact administratif ajoutées.
    """
    df.loc[:, 'siren'] = df['siren'].fillna(-1).astype(int).astype(str)
    
    # Merge avec le tableau des contacts administratifs
    df2 = df.merge(admin_annuaire, on="siren", how='left')
    return df2


if __name__ == "__main__":
    # on garde les colonnes utiles
    df = pd.DataFrame()
    cols_utiles = ['nom', 'siren', 'siret', 'telephone', 'adresse_courriel', 'type_organisme']
    df2 = df.merge(admin_annuaire, on="siren", how='left')
    avec_contact = df2[df2['telephone'].notnull()]
    sans_contact = df2[df2['telephone'].isnull()]

