#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os

os.chdir(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
import pandas as pd
from data.config import path_data


path_group_csv = os.path.join(path_data, "BDNB", "csv_group")

use_cols = ['batiment_groupe_id', 'numero_immat_principal', 'l_usage_1', 'l_type_equipement',
            'identifiant_dpe', 'activitePrincipaleUniteLegale',
            'telephone', 'adresse_courriel', 'type_organisme',
            'siren']
all_df = pd.DataFrame()
for filename in os.listdir(path_group_csv):
    if filename.endswith('.csv'):
        df = pd.read_csv(os.path.join(path_group_csv, filename),
                         usecols=use_cols)
    print(filename)
    print(len(df))
    print(df['identifiant_dpe'].isnull().value_counts(normalize=True))
    all_df = pd.concat([all_df, df])

print(all_df['identifiant_dpe'].isnull().value_counts(normalize=True))
print(all_df['numero_immat_principal'].isnull().value_counts(normalize=True))
print(all_df['l_type_equipement'].isnull().value_counts(normalize=True))
print(all_df['telephone'].notnull().value_counts(normalize=True))
print(all_df['adresse_courriel'].notnull().value_counts(normalize=True))

copro = all_df[all_df['numero_immat_principal'].notnull()]
sans_copro = all_df[all_df['numero_immat_principal'].isnull()]


