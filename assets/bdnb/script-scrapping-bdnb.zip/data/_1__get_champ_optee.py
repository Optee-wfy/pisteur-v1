from re import sub
import geopandas as gpd
from data._1__extract_a_bdnb_table import _read_table

def _get_proprietaire_majic(zip_ref):
    """
    Lit les fichiers de propriétaires et les relie aux groupes de bâtiments.
    """

    with zip_ref.open("csv/" + 'proprietaire' + ".csv") as f:
        prop = _read_table(f, 'proprietaire')
    prop.drop(columns=['dans_majic_pm'], inplace=True)

    with zip_ref.open("csv/" + 'rel_batiment_groupe_proprietaire' + ".csv") as f:
        rel_prop = _read_table(f, 'rel_batiment_groupe_proprietaire')
    rel_prop.drop(columns=['dans_majic_pm'], inplace=True)

    final_prop = rel_prop.merge(prop, on='personne_id', how='outer', suffixes=('_groupe', '_total'), indicator=True)
    assert final_prop._merge.unique() == ['both']
    final_prop.drop(columns=['_merge'], inplace=True)
    return final_prop

def get_bon_proprietaires_majic(zip_ref):
    """
    Obtient les bons propriétaires à partir des fichiers de propriétaires.
    """
    rel_prop = _get_proprietaire_majic(zip_ref)
    # on ne garde que les propriétaires qui sont dans la base Majic PM
    # et qui ont un siren
    rel_prop = rel_prop[rel_prop['siren'].notnull()]
    rel_prop = rel_prop[~rel_prop['siren'].str.startswith('U', na=True)]
    rel_prop = rel_prop[rel_prop['forme_juridique'] != 'SCI']
    return rel_prop

def get_rnic(zip_ref):
    """
    Obtient les données RNIC à partir des fichiers de la BDNB.
    """
    with zip_ref.open("csv/" + 'batiment_groupe_rnc' + ".csv") as f:
        bdnb_rnic = _read_table(f, 'batiment_groupe_rnc')
    # on ne garde que les lignes qui ont un siren
    return bdnb_rnic

def get_synthese_usage(zip_ref):
    """
    Obtient la synthèse de l'usage des bâtiments à partir des fichiers de la BDNB.
    """
    with zip_ref.open("csv/" + 'batiment_groupe_synthese_propriete_usage' + ".csv") as f:
        synthese_usage = _read_table(f, 'batiment_groupe_synthese_propriete_usage')
    return synthese_usage


def adresse_and_nbat(zip_ref):
    with zip_ref.open("csv/" + 'adresse' + ".csv") as f:
        adresse = _read_table(f, 'adresse')

    geom = gpd.GeoSeries.from_wkt(adresse['WKT'], crs=2154) # Lambert 93 = EPSG 2154
    geom = geom.to_crs('WGS84')
    x_y = geom.get_coordinates()
    adresse.loc[:,'x'] = x_y['x']
    adresse.loc[:,'y'] = x_y['y']

    with zip_ref.open("csv/" + 'adresse_metrique' + ".csv") as f:
        adresse_metrique = _read_table(f, 'adresse_metrique')
    
    with zip_ref.open("csv/" + 'rel_batiment_groupe_adresse' + ".csv") as f:
        lien_adresse = _read_table(f, 'rel_batiment_groupe_adresse')
    lien_adresse.drop(columns=['lien_valide'], inplace=True, errors='ignore')


    lien_adresse = lien_adresse.merge(
        adresse,
        on='cle_interop_adr',
        how='left'
    )
    lien_adresse.drop_duplicates(
        subset=['batiment_groupe_id'],
        inplace=True
    )
    lien_adresse = lien_adresse.merge(
        adresse_metrique,
        on='cle_interop_adr',
        how='left'
    )
    return lien_adresse[['batiment_groupe_id', 'x', 'y', 'nb_bat_grp', 'nb_bat_grp_hors_dep']]


def get_orpee_table(zip_ref):
    """
    Obtient la table ORPEE à partir des fichiers de la BDNB.
    """
    bdnb_rnic = get_rnic(zip_ref)
    majic = get_bon_proprietaires_majic(zip_ref)
    usage = get_synthese_usage(zip_ref)
    adresse = adresse_and_nbat(zip_ref)

    out = bdnb_rnic.merge(majic, on='batiment_groupe_id', how='outer')
    out = out.merge(usage, on='batiment_groupe_id', how='left')
    out = out.merge(adresse, on='batiment_groupe_id', how='left')

    # on ne garde que les bâtiments qui ont un usage principal 
    filtre1 = out['numero_immat_principal'].notnull()
    # on met de côté le "Indifférencié"
    filtre1 = filtre1 | out['usage_principal_bdnb_open'].isin(['Tertiaire'])
    out = out[filtre1]

    ## filtre sur le nombre de propriétaires
    out = out.groupby('batiment_groupe_id').filter(lambda x: len(x) == 1)
    return out


if __name__ == "__main__":
    import zipfile
    import os

    path_data = "path_to_your_data_directory"  # Change this to your actual data directory
    id_dep = "your_department_id"  # Change this to your actual department ID

    path = os.path.join(path_data, "BDNB", "zip", f'2024-10-a_dep{id_dep}_csv.zip')
    zip_ref = zipfile.ZipFile(path, 'r')

    orpee_table = get_orpee_table(zip_ref)

    out['batiment_groupe_id']
    voir = out[out['batiment_groupe_id'] == 'bdnb-bg-JG7B-1F7R-65UQ']

    vmajic = majic[majic['batiment_groupe_id'] == 'bdnb-bg-JG7B-1F7R-65UQ']
    vusage = usage[usage['batiment_groupe_id'] == 'bdnb-bg-JG7B-1F7R-65UQ']
    vadresse = adresse[adresse['batiment_groupe_id'] == 'bdnb-bg-JG7B-1F7R-65UQ']

    zip_ref.close()