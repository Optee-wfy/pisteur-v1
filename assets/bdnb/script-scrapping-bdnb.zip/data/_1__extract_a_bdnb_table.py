

"""
Transforms a DataFrame containing building energy data across multiple years ("millesimes") into a pivoted format.

Part 1 - Travaille par table
Part 2 - Fait le job pour tout
"""
import csv
import os
import zipfile
import pandas as pd
import geopandas as gpd
from data.config import path_data



# Part 1 - Travaille par table

def transform_bdnb_multimillesime(tab, suffixe):
    tab.drop(columns=[x for x in tab.columns if 'par_pdl' in x], inplace=True, errors='ignore')  # Remove index column if it exists
 
    assert suffixe in ['gaz', 'elec', 'reseaux']
    # ancienne méthod où on gardait une ligne avec toutes les années
    # out = tab.pivot(index='batiment_groupe_id', columns='millesime')
    # if 'code_departement_insee' in out.columns:
    #     out = out.drop(columns=['code_departement_insee'])
    # out.columns = [x[0] + '_' + suffixe + '_' + str(x[1]) for x in out.columns]
    # out.reset_index(inplace=True)
    # return out

    # on vérifie qu'on a au moins une valeur par id
    # semble logique car sinon ne serait pas dans la base
    # mais on sait jamais...
    isnull = tab.isnull().any(axis=1)
    nb_millesime = tab['millesime'].nunique()
    assert (tab[isnull].groupby('batiment_groupe_id').size() < max(nb_millesime, 2)).all()
    # le 2 au dessus c'est pour les cas, où on a un seul millésime.
    
    tab.sort_values(by=['batiment_groupe_id', 'millesime'], inplace=True)
    tab.bfill(inplace=True)
    max_millesime = tab['millesime'].max()
    last_known_millesime = tab[tab['millesime'] == max_millesime]
    return last_known_millesime



def transform_batiment_construction(tab):
    ''' on va garder la géométrie pour avoir le périmètre et la surface du bâtiment'''
    ## on va calculer la surface "vitrée" du bâtiment
    gdf = gpd.GeoSeries.from_wkt(tab['WKT'], crs=2154) # Lambert 93 = EPSG 2154
    perim = gdf.length
    tab.loc[:, 'perimetre'] = perim.round()
    tab.loc[:, 'surface_vitre'] = (tab['hauteur'] * perim).round()
    tab.drop(columns=['WKT'], inplace=True)
    return tab


table_transformation = {
    "batiment_construction": transform_batiment_construction,
    "batiment_groupe_dle_elec_multimillesime": lambda x: transform_bdnb_multimillesime(x, suffixe='elec'),
    "batiment_groupe_dle_gaz_multimillesime": lambda x: transform_bdnb_multimillesime(x, suffixe='gaz'),
    "batiment_groupe_dle_reseaux_multimillesime": lambda x: transform_bdnb_multimillesime(x, suffixe='reseaux'),
    "batiment_groupe_radon": lambda x: x.rename(columns={"alea": "alea_radon"}), 
    "batiment_groupe_argiles": lambda x: x.rename(columns={"alea": "alea_argiles"}),
    "rel_batiment_construction_rnb": lambda x: x,  # No transformation needed
}

## suppression des variables gégoraphiques
# on note les variables que l'on va garder pour utiliser usecols dans le read_csv et ne pas charger d'abord puis faire un drop
# WKT de rel_batiment_construction_rnb, rel_batiment_construction_adresse, de adresse, de batiment_construction et de rel_batiment_groupe_adresse
cols_to_keep = {
    "rel_batiment_groupe_adresse": ["batiment_groupe_id", "cle_interop_adr", "lien_valide"] ,
    "rel_batiment_construction_rnb": ["batiment_construction_id", "rnb_id"],
    # "batiment_construction": ["batiment_construction_id", "batiment_groupe_id", "s_geom_cstr", "hauteur", "altitude_sol", "fictive_geom_cstr", "geom_cstr"],
    "batiment_groupe": ["batiment_groupe_id", "s_geom_groupe", "code_iris", "code_commune_insee", "code_epci_insee", "contient_fictive_geom_groupe"],
    "rel_batiment_construction_adresse": ["batiment_construction_id", "cle_interop_adr", "distance_batiment_construction_adresse", "fiabilite", "adresse_principale"],
    # "batiment_groupe_dpe_representatif_logement": ["identifiant_dpe", "batiment_groupe_id"]
}

def _read_table(f, filename, brut=False):
    """
    Reads a CSV file from a zip archive and processes it.
    """
    columns = cols_to_keep[filename] if filename in cols_to_keep else None
    if brut:
        columns=None
    df_file = pd.read_csv(f, encoding='utf8', usecols=columns, nrows=None)
    df_file.drop(columns=['code_departement_insee'], inplace=True, errors='ignore')  # Remove index column if it exists
    return df_file


def get_bdnb_table(id_dep, filename, brut=False):
    path = os.path.join(path_data, "BDNB", "zip", f'2024-10-a_dep{id_dep}_csv.zip')
    zip_ref = zipfile.ZipFile(path, 'r')
    with zip_ref.open("csv/" + filename + ".csv") as f:
        out = _read_table(f, filename, brut=brut)
    return out


