import os
import pandas as pd
path = r"/home/alexis/git/BDNB/Majic/Fichiers des locaux (situation 2024)"

all_files = []
for file in os.listdir(path):
    if file.endswith('.csv'):
        print(file)
        df = pd.read_csv(os.path.join(path, file),
                         encoding='utf8', sep=';', nrows=10)
        all_files.append(df)

final = pd.concat(all_files, ignore_index=True)


if __name__ == "__main__":    
    df = pd.read_csv(os.path.join(path, 'PM_24_B_750.csv'),
                        encoding='utf8', sep=';', nrows=None)
    st_denis = df[df['Nom voie'].str.contains('DU FBG SAINT DENIS', na=False)]
    st_denis_9 = st_denis[st_denis['N° voirie'] == 9]


