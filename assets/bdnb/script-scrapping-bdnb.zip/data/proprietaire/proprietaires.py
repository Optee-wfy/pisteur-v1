

import os
os.chdir(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
import zipfile
import pandas as pd
from data.config import path_data
from data._1__extract_a_bdnb_table import _read_table


id_dep = '75'


path = os.path.join(path_data, "BDNB", "zip", f'2024-10-a_dep{id_dep}_csv.zip')
zip_ref = zipfile.ZipFile(path, 'r')

filename = "proprietaire"
with zip_ref.open("csv/" + filename + ".csv") as f:
    prop = _read_table(f, filename)

assert all(prop['dans_majic_pm'] == 1)
prop.drop(columns=['dans_majic_pm'], inplace=True)


filename = "rel_batiment_groupe_proprietaire"
with zip_ref.open("csv/" + filename + ".csv") as f:
    rel_prop = _read_table(f, filename)

assert all(rel_prop['dans_majic_pm'] == 1)
rel_prop.drop(columns=['dans_majic_pm'], inplace=True)

# les suffixes sont calés sur la seule variables communes
rel_prop = rel_prop.merge(prop, on='personne_id', how='outer', suffixes=('_groupe', '_total'), indicator=True)
assert rel_prop._merge.unique() == ['both']
rel_prop.drop(columns=['_merge'], inplace=True)



rel_prop['denomination'].str.contains('CRAUNOT', na=False).value_counts()
craunot = rel_prop[rel_prop['denomination'].str.contains('CRAUNOT', na=False)]
# optionnel 
craunot_rnc = craunot[craunot['denomination'].str.contains('POISSONNIERE', na=False)]

craunot_rnc['denomination'].value_counts()
craunot_rnc['siren'].value_counts()
# U20755639 !! temporaire donc non exploitable...
# alors qu'on est toujours sur 335149647

craunot_rnc.iloc[8]

# à paris on a 16 % de valeurs manquantes pour les sirens
rel_prop.siren.str.startswith('U',na=True).value_counts(normalize=True)
