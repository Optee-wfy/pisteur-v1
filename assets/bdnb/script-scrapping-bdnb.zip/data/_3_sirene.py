import os
import pandas as pd
os.chdir(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
from data.config import path_data

path_group_csv = os.path.join(path_data, "BDNB", "csv_group")
path_sirene = r'/home/alexis/git/BDNB/sirene'

def add_sirene(tab):
    tab.loc[:, 'siren'] = tab['siren'].fillna(-1).astype(int).astype(str)

    sirene = pd.read_parquet(
        os.path.join(path_sirene, "StockUniteLegale_utf8.parquet"),
        filters=([('siren', 'in', tab['siren'].unique())])
    )

    sirene.drop(columns=sirene.columns[sirene.isnull().sum() > 0.7*len(sirene)], inplace=True)
    a_garder = ['siren',
        'trancheEffectifsUniteLegale', 'anneeEffectifsUniteLegale',
        'categorieEntreprise', 'anneeCategorieEntreprise',
        'etatAdministratifUniteLegale', 'denominationUniteLegale',
        'categorieJuridiqueUniteLegale', 'activitePrincipaleUniteLegale',
        'nomenclatureActivitePrincipaleUniteLegale',
        'economieSocialeSolidaireUniteLegale']
    sirene = sirene[a_garder]

    tab = tab.merge(sirene, on='siren', how='left', suffixes=('', '_sirene'),
            indicator='in_sirene')
    return tab


def add_siret(tab):
    tab.loc[:, 'siret'] = tab['siret'].fillna(-1).astype(int).astype(str)

    sirene_et = pd.read_parquet(
        os.path.join(path_sirene, "StockEtablissement_utf8.parquet"),
        filters=([('siret', 'in', tab['syndic_siret'].unique())])
    )

    a_garder = ['siret',
                'numeroVoieEtablissement', 'indiceRepetitionEtablissement',
        'typeVoieEtablissement', 'libelleVoieEtablissement',
        'codePostalEtablissement', 'libelleCommuneEtablissement'
        ]
    sirene_et = sirene_et[a_garder]
    sirene_et.rename(columns={
        'siret': 'syndic_siret'
        }, inplace=True)
    sirene_et.columns = [x.replace('Etablissement', '_syndic') for x in sirene_et.columns]
    tab = tab.merge(sirene_et, on='syndic_siret', how='left', suffixes=('', '_sirene'),)
    return tab




if __name__ == "__main__":
    tab = pd.DataFrame(columns=['siren'])

    sirene = pd.read_parquet(
        os.path.join(path_sirene, "StockUniteLegale_utf8.parquet"),
        filters=([('siren', 'in', tab['siren'].unique())])
    )
    valeurs_sirene = tab.iloc[:, -sirene.shape[1]:].notnull().sum()
    columns_to_select = [
        "siren",
        "forme_juridique",
        "denomination",
        "code_postal",
        "libelle_commune"
    ]

    test = tab[columns_to_select].merge(
        sirene, on='siren',suffixes=('', '_sirene'),
            how='inner')
    test.loc[test['forme_juridique'] == "COM", 'categorieJuridiqueUniteLegale'].value_counts()
    test.loc[test['forme_juridique'] == "SC", 'categorieJuridiqueUniteLegale'].value_counts()
    test.loc[test['forme_juridique'] == "SA", 'categorieJuridiqueUniteLegale'].value_counts()