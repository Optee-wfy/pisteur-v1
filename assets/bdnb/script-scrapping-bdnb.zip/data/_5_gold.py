#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
on garde les batiments avec dpe en fait non, tous

Ce n'est qu'ici qu'on fait la jonction rnic

"""

import os

os.chdir(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
import pandas as pd
from data.config import path_data

from data.archives.metier_api import original_name_to_new_name
from data._3_sirene import add_siret

path_group_csv = os.path.join(path_data, "BDNB", "csv_group")
path_final_csv = os.path.join(path_data, "BDNB", "csv_final")

use_cols = ['batiment_groupe_id', 'numero_immat_principal', 'l_usage_1', 'l_type_equipement',
            'identifiant_dpe', 'activitePrincipaleUniteLegale',
            'telephone', 'adresse_courriel', 'type_organisme',
            'siren']

sans_copro = pd.DataFrame()
# on sépare en faisant un boucle copro et un boucle sans_copr
# pour réduire la taille
copro = pd.DataFrame()
rnic = pd.read_csv("/home/alexis/git/BDNB/RNIC/rnc-data-gouv-with-qpv.csv",
                   encoding='utf8', usecols=[
                       "Numéro d'immatriculation",
                       'SIRET du représentant légal',
                       'Commune du représentant légal',
                       'Syndicat principal ou syndicat secondaire'], nrows=None)
rnic.rename(columns={
    "Identification du représentant légal  (raison sociale et le numéro SIRET du syndic professionnel ou Civilité/prénom/ nom du syndic bénévole ou coopératif)": "syndic_nom",
    'Numéro d\'immatriculation': 'numero_immat_principal',
    'SIRET du représentant légal': 'syndic_siret',
    'Commune du représentant légal':'syndic_commune',
    'Syndicat principal ou syndicat secondaire': 'syndic_principal',
}, inplace=True)

for filename in os.listdir(path_group_csv):
    if filename.endswith('.csv'):
        df = pd.read_csv(os.path.join(path_group_csv, filename),
                         usecols=None)
        
        copro = df[df['numero_immat_principal'].notnull()]
        copro = df.merge(rnic, on="numero_immat_principal")
        copro = add_siret(copro)
        xxx
        copro.to_csv(os.path.join(path_final_csv, 'copro_' + filename))
        # sans_copro = pd.concat([sans_copro,  df[df['numero_immat_principal'].isnull()]])

# Si total et non par bout
#         df = df[df['numero_immat_principal'].notnull()]
#         df = df.merge(rnic, on="numero_immat_principal")
#         df = add_siret(df)
#         # df = df[df['identifiant_dpe'].notnull()]
#         copro = pd.concat([copro,  df])
#         # sans_copro = pd.concat([sans_copro,  df[df['numero_immat_principal'].isnull()]])

# copro.to_csv(os.path.join(path_final_csv, 'copro.csv'))

xxx

for filename in os.listdir(path_group_csv):
    if filename.endswith('.csv'):
        df = pd.read_csv(os.path.join(path_group_csv, filename),
                         usecols=None)
        df = df[df['numero_immat_principal'].isnull()]
        # df = df[df['identifiant_dpe'].notnull()]
        sans_copro = pd.concat([sans_copro,  df])
        # sans_copro = pd.concat([sans_copro,  df[df['numero_immat_principal'].isnull()]])

sans_copro.to_csv(os.path.join(path_final_csv, 'sans_copro.csv'))

sans_copro['activitePrincipaleUniteLegale'].value_counts(dropna=False, normalize=True)
codes_naf_dict = {
    "68.20A": "Location de logements - Bailleurs sociaux, foncières résidentielles",
    "68.20B": "Location de terrains et d'autres biens immobiliers - Foncières tertiaires",
    "87.10A": "Hébergement médicalisé pour personnes âgées - EHPAD",
    "87.10B": "Hébergement médicalisé pour autres catégories - Cliniques spécialisées",
    "86.10Z": "Activités hospitalières - Hôpitaux publics/privés",
    "86.21Z": "Activité des médecins généralistes - Cabinets médicaux (parfois regroupés)",
    "85.20Z": "Enseignement secondaire général - Collèges, lycées (privés notamment)",
    "85.10Z": "Enseignement pré-primaire - Crèches privées, maternelles privées",
    "85.32Z": "Enseignement secondaire technique ou professionnel - Lycées techniques",
    "85.42Z": "Enseignement supérieur - Écoles, universités, campus",
    "55.10Z": "Hôtels et hébergement similaire - Bâtiments énergivores",
    "55.20Z": "Hébergement touristique et autres hébergements de courte durée - Gîtes, résidences de tourisme",
    "55.30Z": "Terrains de camping et parcs pour caravanes ou véhicules de loisirs - Site technique + logement",
    "47.11F": "Hypermarchés - Grandes surfaces à fort besoin énergétique",
    "47.11D": "Supermarchés - Idem",
    "47.11E": "Magasins multi-commerces - Centres commerciaux"
}

# par construction on est "hors public"
codes_naf = list(codes_naf_dict.keys())
selections = sans_copro['activitePrincipaleUniteLegale'].isin(codes_naf)
selections = selections # | df['numero_immat_principal'].notnull()
sans_copro = sans_copro[selections]


### Post traitement des tables
columns_found = sans_copro.columns.tolist()
not_found = [col for col in original_name_to_new_name if col not in columns_found]
found = [col for col in original_name_to_new_name if col in columns_found]
print("Columns not found in the data:", not_found)
print('length of not found:', len(not_found))


interet_premier['siren'].value_counts()
## point sur les
cols_nature = [x for x in df.columns if 'nature' in x] + ['l_toponyme', 'l_usage_1', 'l_usage_2', 'l_type_equipement']
df[cols_nature].notnull().sum()
for col in cols_nature:
    print('\n ', col)
    print(df[col].value_counts())
df['l_type_equipement'].value_counts(dropna=False)
