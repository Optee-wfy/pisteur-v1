#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Documentation for the BDNB data extraction script.
https://open-data.s3.fr-par.scw.cloud/bdnb_millesime_2024-10-a/millesime_2024-10-a_doc/documentation.xlsx


https://gitlab.com/BDNB/base_nationale_batiment


"""
import os
os.chdir(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
from data._1__get_champ_optee import get_orpee_table
import zipfile
import pandas as pd
from data.config import path_data
from data._1__extract_a_bdnb_table import _read_table, table_transformation
from data.archives.metier_api import original_name_to_new_name
import geopandas as gpd



def _filters_some_csvfiles(csv_file_names):
    """
    Filtre les noms de fichiers CSV pour ne garder que ceux qui sont pertinents.
    """
    
    csv_file_names = [x for x in csv_file_names if x not in ["parcelle"]]
    dvf_files = [x for x in csv_file_names if 'dvf' in x]
    sitadel_files = [x for x in csv_file_names if 'sitadel' in x]
    merimee_files = [x for x in csv_file_names if 'merimee' in x]

    # analyse dpe :
    # il y a quatre tables, cf. analyses/dpe.py
    # on garde que batiment_groupe_dpe_representatif_logement qui a déjà fait le boulot
    dpe_files = ["rel_batiment_groupe_dpe_logement", "dpe_logement"]

    to_exclude = ['batiment_groupe_hthd', 'dpe_logement'] + dvf_files + sitadel_files + dpe_files + merimee_files
    # batiment_groupe_hthd parce pas d'intérêt pour l'instant
    
    csv_file_names = [x for x in csv_file_names if x not in to_exclude]
    # - rel_batiment_groupe_qpv : Table dépréciée et entièrement remplacée par batiment_groupe_qpv
    csv_file_names = [x for x in csv_file_names if x != "rel_batiment_groupe_qpv"]

    # on ne fait pas le lien avec la bases des équipements ou avec la bdtopo
    # rel_batiment_groupe_merimee : distance au patrmoine on laisse tomber (lien avec plusieurs batiments donc multiplie le nombre de lignes)    
    # rel_batiment_groupe_bdtopo_zoa et rel_batiment_groupe_bdtopo_equ envoie un batiment sur plusieurs bdtopo_zoa_cleabs
    table_to_exclude = ["rel_batiment_groupe_bpe",
                        "rel_batiment_groupe_bdtopo_zoa", 
                        "rel_batiment_groupe_bdtopo_equ",
                          "rel_batiment_groupe_merimee"]
    csv_file_names = [x for x in csv_file_names if x not in table_to_exclude]  
    csv_file_names = [x for x in csv_file_names
                      if x not in table_to_exclude]
    # on exclut cela par facilité mais il faudra certainement revenir dessus et utiliser ces données
    temp_exclude = [
                    'rel_batiment_construction_adresse',
                    'rel_batiment_groupe_proprietaire',
                    "rel_batiment_groupe_bpe", 
                    'rel_batiment_groupe_rnc',
                    'rel_batiment_groupe_parcelle'
                    ]
    csv_file_names = [x for x in csv_file_names
                      if x not in temp_exclude]
    return csv_file_names


departements = [f"{i:02d}" for i in range(1, 96)] + ["2a", "2b"]
departements.remove('20')
for id_dep in departements:
    path = os.path.join(path_data, "BDNB", "zip", f'2024-10-a_dep{id_dep}_csv.zip')
    zip_ref = zipfile.ZipFile(path, 'r')

    csv_files = [f for f in zip_ref.namelist() if f.endswith('.csv')]
    csv_file_names = [os.path.basename(csv_file).replace('.csv', '') for csv_file in csv_files]
    csv_file_names = _filters_some_csvfiles(csv_file_names)

    champ_files = ['proprietaire', 'rel_batiment_groupe_proprietaire', 'batiment_groupe_rnc', 'batiment_groupe_synthese_propriete_usage']
    champ_files += ['adresse_metrique', 'adresse', 'rel_batiment_groupe_adresse']
    csv_file_names = set(csv_file_names) - set(champ_files)

    ### intialisation des sortie
    construction_table = pd.DataFrame(columns=["batiment_construction_id"])
    groupe_table = get_orpee_table(zip_ref)
    nb_cols_tab = dict() # pour avoir le nombre de colonnes dans chaque fichier CSV
    for filename in list(csv_file_names):
        print('- table', filename)
        with zip_ref.open("csv/" + filename + ".csv") as f:
            df_file = _read_table(f, filename)
            print("shape of", filename, ":", df_file.shape, "rows and cols" )
            nb_cols_tab[filename] = len(df_file.columns)
            if "batiment_construction_id" in df_file.columns:
                # print('On met de côté tout ce qui a trait à batiment_construction_id')
                if 'batiment_groupe_id' in df_file.columns:
                    df_file.drop(columns=['batiment_groupe_id'], inplace=True)
                assert df_file['batiment_construction_id'].nunique() == len(df_file), "batiment_construction_id should be unique in filename"
                continue 
                # on met de côté l'info au niveau batiment pour l'instant
                construction_table = construction_table.merge(df_file,
                                                            on = "batiment_construction_id", how= 'outer',
                                                            suffixes=('', '_' + filename))
                print("construction : after merge with", filename, ":", construction_table.shape, "rows and cols" )
                if df_file['batiment_construction_id'].nunique() < len(df_file):
                    print(f"************Warning: 'batiment_construction_id' not unique in {filename}")
            else:
                if 'batiment_groupe_id' not in df_file.columns:
                    print(f"Warning: 'batiment_groupe_id' not found in {filename}")
                    continue
                
                df_file = df_file[df_file['batiment_groupe_id'].isin(groupe_table['batiment_groupe_id'])]
                if filename in table_transformation:
                    df_file = table_transformation[filename](df_file)
                assert df_file['batiment_groupe_id'].nunique() == len(df_file), "batiment_groupe_id should be unique in filename"

                
                groupe_table = groupe_table.merge(df_file,
                                            on = "batiment_groupe_id", how='left',
                                            suffixes=('', '_' + filename))
                
                
                if df_file['batiment_groupe_id'].nunique() < len(df_file):
                    print(f"************Warning: 'batiment_groupe_id' not unique in {filename}")
                print("group after merge with", filename, ":", groupe_table.shape, "rows and cols" )
    zip_ref.close()
    # sauvgarde  :
    groupe_table.to_csv(os.path.join(path_data, "BDNB", "csv", f'batiment_groupe_{id_dep}.csv'), index=False, encoding='utf8')
    # construction_table.to_csv(os.path.join(path_data, "BDNB", "csv", f'batiment_construction_{id_dep}.csv'), index=False, encoding='utf8')


# TODO: la colonne nb_loc apparait à la fois dans les fichiers fonciers 
# et dans le batiment_groupe_rnc

### Post traitement des tables
# nb_cols_tab_serie = pd.Series(nb_cols_tab)
# columns_found = groupe_table.columns.tolist() + construction_table.columns.tolist()
# not_found = [col for col in original_name_to_new_name if col not in columns_found]
# found = [col for col in original_name_to_new_name if col in columns_found]
# print("Columns not found in the data:", not_found)
# print('length of not found:', len(not_found))


xxx


# on a bcp de répétitions de code departement dans les colonnes
codes_dep = [x for x in groupe_table.columns if x.startswith('code_dep')]
# analyse des codes departement
test = groupe_table[codes_dep].apply(lambda x: x.nunique(), axis=1)
test.value_counts()
assert all(test == 1), "Il y a des codes departement qui ne sont pas uniques dans les lignes du tableau batiment_groupe"
assert groupe_table[codes_dep].equals(id_dep)
groupe_table.drop(columns=codes_dep, inplace=True)

   
#### variables de conso => il y en a 111 (pour les données jusqu'en 2022)
conso_var = [x for x in groupe_table.columns if x.startswith('conso_') or x.startswith('nb_pdl_')]
print("Variables de consommation:", conso_var)
groupe_table.drop(columns=conso_var, inplace=True, errors='ignore')


# csv/adresse.csv est specifique (en lien avec avec cle_interop_adr et pas avec le batiment)

# nature 
tab_nature = ['l_nature_batiment_groupe_bdtopo_bat', 'l_usage_1', 'l_usage_2']



# pour étudier le contenu des fichiers CSV
if __name__ == "__main__":
    pass



# TODO: regarder RNB
# https://rnb-fr.gitbook.io/documentation/exemples/obtenir-des-attributs-metier-a-partir-dun-identifiant-rnb-id-rnb
# [{"id": "bdnb-bc-2FZV-5RZD-U2PF", "source": "bdnb", "created_at": "2023-12-10T10:32:37.813737+00:00", "source_version": "2023_01"}, {"id": "BATIMENT0000000244513859", "source": "bdtopo", "created_at": "2023-12-21T18:49:05.094022+00:00", "source_version": "bdtopo_2023_09"}]


# path = r"/home/alexis/git/BDNB/open_data_millesime_2024-10-a_france_csv.tar.gz"

# # fichier foncier
# https://rnb.beta.gouv.fr/blog/fichiers-fonciers




# ### registre des coproprietaires



# # Registre National d'Immatriculation des Copropriétés
# https://www.data.gouv.fr/datasets/registre-national-dimmatriculation-des-coproprietes/


# ###
# https://data.economie.gouv.fr/explore/dataset/fichiers-des-locaux-et-des-parcelles-des-personnes-morales/information/


