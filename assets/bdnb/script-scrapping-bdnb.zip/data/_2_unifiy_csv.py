import os

os.chdir(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
import pandas as pd
from data.config import path_data

from data._3_sirene import add_sirene
from data._4_ajout_contact_mairie import add_contact_admin


from data.archives.metier_api import original_name_to_new_name

# TODO: avoir un propriétaire par batiment

path_csv = os.path.join(path_data, "BDNB", "csv")

df_list = []
df = pd.DataFrame()
total_len = 0
avec_dpe = 0
count = 0

for filename in os.listdir(path_csv):
    if filename.endswith('.csv'):
        tab = pd.read_csv(os.path.join(path_csv, filename))
        avec_dpe += tab['identifiant_dpe'].notnull().sum()
        tab.drop(columns=tab.columns[tab.isnull().sum() > 0.7*len(tab)], inplace=True)
   
        df = pd.concat([df, tab])
        count += 1
        total_len += len(tab)
    # if count % 20 == 0:
    #     df = add_sirene(df)
    #     df = add_contact_admin(df)
    #     df.to_csv(os.path.join(path_data, 'BDNB', "csv_group", str(count) + '.csv'), index=False)
    #     df = pd.DataFrame()
# pour le final 
df = add_sirene(df)
df = add_contact_admin(df)
df.to_csv(os.path.join(path_data, 'BDNB', "csv_group", str(count) + '.csv'), index=False)


print('total number of rows:', total_len)
print('total number of rows with identifiant_dpe:', avec_dpe)
print('pourcentage avec dpe: ', avec_dpe / total_len * 100)
xxx
path_group_csv = os.path.join(path_data, "BDNB", "csv_group")

xx
for filename in os.listdir(path_group_csv):
    if filename.endswith('.csv'):
        df = pd.read_csv(os.path.join(path_group_csv, filename))
    print(filename)
    print(len(df))
    print(df['identifiant_dpe'].isnull().value_counts(normalize=True))


## point sur les
cols_nature = [x for x in df.columns if 'nature' in x] + ['l_toponyme', 'l_usage_1', 'l_usage_2', 'l_type_equipement']
df[cols_nature].notnull().sum()
for col in cols_nature:
    print('\n ', col)
    print(df[col].value_counts())
df['l_type_equipement'].value_counts(dropna=False)




# l_nature_batiment_groupe_bdtopo_equ	l_nature_detaillee
# l_nature_batiment_groupe_bdtopo_zoac

# 350630 + 187433 + 266895 + 391799 + 204983 + 227556 + 218784 + 159252 + 249400
# 168013 + 108974 + 121144 + 277079 + 119175 + 129322 + 110194 + 94249 + 146989 
# not_found = [col for col in original_name_to_new_name if col not in df.columns]
# not_found
# ['annee_construction',
#  'usage_niveau_1_txt',
#  'type_energie_chauffage',
#  'type_installation_chauffage',
#  'classe_bilan_dpe',
#  'l_parcelle_id',
#  'conso_5_usages_ep_m2',
#  'emission_ges_5_usages_m2',
#  'pourcentage_surface_baie_vitree_exterieur',
#  'nb_niveau',
#  'geom_groupe',
#  'type_generateur_ecs',
#  'classe_inertie',
#  'presence_balcon',
#  'nb_log_rnc',
#  'nb_lot_tertiaire_rnc',
#  'nb_pdl_res_elec_2020',
#  'nb_pdl_pro_elec_2020',
#  'nb_pdl_pro_gaz_2020',
#  'nb_pdl_res_gaz_2020',
#  'arrete_2021',
#  'identifiant_dpe',
#  'emission_ges_3_usages_ep_m2_arrete_2012',
#  'type_ventilation',
#  'type_generateur_climatisation',
#  'type_generateur_climatisation_anciennete',
#  'type_isolation_mur_exterieur',
#  'u_mur_exterieur',
#  'type_isolation_plancher_bas',
#  'type_isolation_plancher_haut',
#  'u_plancher_bas_final_deperditif',
#  'u_plancher_haut_deperditif',
#  'type_vitrage',
#  'type_materiaux_menuiserie',
#  'type_gaz_lame',
#  'type_fermeture',
#  'vitrage_vir',
#  'u_baie_vitree',
#  'facteur_solaire_baie_vitree',
#  'conso_pro_elec_2020',
#  'conso_res_elec_2020',
#  'conso_pro_gaz_2020',
#  'conso_res_gaz_2020',
#  'id_reseau',
#  'alea_argiles',
#  'quartier_prioritaire',
#  'nom_quartier',
#  'code_qp']


# #### je cherche qui envoyer à un truc  de contact.
# df[df['forme_juridique'] == "SA"]['denomination'].value_counts()

# # peut-être pas ENEDIS ou ORANGE
# df[df['forme_juridique'] == "SA"].groupby('denomination').filter(lambda x: len(x) < 10)['denomination']

# # test hotelier





df['siren'].nunique()
# 255 519

df['activitePrincipaleUniteLegale'].value_counts()
# 255 519

codes_naf_dict = {
    "68.20A": "Location de logements - Bailleurs sociaux, foncières résidentielles",
    "68.20B": "Location de terrains et d'autres biens immobiliers - Foncières tertiaires",
    "87.10A": "Hébergement médicalisé pour personnes âgées - EHPAD",
    "87.10B": "Hébergement médicalisé pour autres catégories - Cliniques spécialisées",
    "86.10Z": "Activités hospitalières - Hôpitaux publics/privés",
    "86.21Z": "Activité des médecins généralistes - Cabinets médicaux (parfois regroupés)",
    "85.20Z": "Enseignement secondaire général - Collèges, lycées (privés notamment)",
    "85.10Z": "Enseignement pré-primaire - Crèches privées, maternelles privées",
    "85.32Z": "Enseignement secondaire technique ou professionnel - Lycées techniques",
    "85.42Z": "Enseignement supérieur - Écoles, universités, campus",
    "55.10Z": "Hôtels et hébergement similaire - Bâtiments énergivores",
    "55.20Z": "Hébergement touristique et autres hébergements de courte durée - Gîtes, résidences de tourisme",
    "55.30Z": "Terrains de camping et parcs pour caravanes ou véhicules de loisirs - Site technique + logement",
    "47.11F": "Hypermarchés - Grandes surfaces à fort besoin énergétique",
    "47.11D": "Supermarchés - Idem",
    "47.11E": "Magasins multi-commerces - Centres commerciaux"
}

# par construction on est "hors public"

codes_naf = list(codes_naf_dict.keys())
selections = df['activitePrincipaleUniteLegale'].isin(codes_naf)
selections = selections # | df['numero_immat_principal'].notnull()
interet_premier = df[selections]
interet_premier['siren'].value_counts()


interet_premier['siren'].nunique()
stats = interet_premier.groupby('activitePrincipaleUniteLegale').apply(
    lambda x:pd.Series({
        'label': codes_naf_dict[x.name],
        'nunique_siren': x['siren'].nunique(), 
        'batiment_total': len(x),
        'l_usage_preponderant': x['l_usage_1'].value_counts().index[:3].tolist(),
        }))



copro = df[df['numero_immat_principal'].notnull()]
xx

stats.loc[:, 'label'] = stats.index.map(codes_naf_dict)

# ajouter une colonne publique. 


l_usage_1                                 [ "Commercial et services", "Résidentiel" ]
l_usage_2                                                                [ "Annexe" ]
l_etat                                                               [ "En service" ]
sous_  = interet_premier[interet_premier['activitePrincipaleUniteLegale'] == '68.20B']

# 2 300 000 une ou plusieurs personnes

# stats copro tertiaire.
