

import os
from more_itertools import last
import pandas as pd
os.chdir(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
from data.extract_a_bdnb_table import get_bdnb_table

dep = "29"

tab = get_bdnb_table(dep, 'batiment_groupe_dle_reseaux_multimillesime', brut=True)
suffixe = 'gaz'
tab.drop(columns=[x for x in tab.columns if 'par_pdl' in x], inplace=True, errors='ignore')  # Remove index column if it exists


assert suffixe in ['gaz', 'elec', 'reseaux']
# on vérifie qu'on a au moins une valeur par id
# semble logique car sinon ne serait pas dans la base
# mais on sait jamais...
isnull = tab.isnull().any(axis=1)
nb_millesime = tab['millesime'].nunique()
assert (tab[isnull].groupby('batiment_groupe_id').size() < max(nb_millesime, 2)).all()

tab.sort_values(by=['batiment_groupe_id', 'millesime'], inplace=True)
tab.fillna(method='bfill', inplace=True)
max_millesime = tab['millesime'].max()
last_known_millesime = tab[tab['millesime'] == max_millesime]


out = tab.pivot(index='batiment_groupe_id', columns='millesime')
if 'code_departement_insee' in out.columns:
    out = out.drop(columns=['code_departement_insee'])
out.columns = [x[0] + '_' + suffixe + '_' + str(x[1]) for x in out.columns]
out.reset_index(inplace=True)


#     columns = cols_to_keep[filename] if filename in cols_to_keep else None
#     df_file = pd.read_csv(f, encoding='utf8', usecols=columns, nrows=None)
#     df_file.drop(columns=['code_departement_insee'], inplace=True, errors='ignore')  # Remove index column if it exists
#     if filename in table_transformation:
#         df_file = table_transformation[filename](df_file)


#     path = os.path.join(path_data, "BDNB", "zip", f'2024-10-a_dep{id_dep}_csv.zip')
#     zip_ref = zipfile.ZipFile(path, 'r')
#     with zip_ref.open("csv/" + filename + ".csv") as f:
#         out = _read_table(f, filename)


# bdnb_rnic['l_type_pdl'].value_counts()
# bdnb_rnic['l_nom_pdl'].value_counts()
# bdnb_rnic['nb_pdl'].value_counts()

# departements = [f"{i:02d}" for i in range(1, 96)] + ["2a", "2b"]
# departements.remove('20')
# for dep in departements:
#     bdnb_rnic = get_bdnb_table(dep, 'batiment_groupe_dle_gaz_multimillesime')
#     assert bdnb_rnic['l_nom_pdl'].isnull().all(), "Il y a des noms de PDL dans la table batiment_groupe_hthd, ce n'est pas normal !"

