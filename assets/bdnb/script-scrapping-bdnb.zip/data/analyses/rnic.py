''' 
Stratégie qui se déduit de cette analyse :
on utilise les adresses de la BDNB. On cherche qui est la copro
et on va chercher cette copro dans le RNIC avec le numéro d'immatriculation.

Quand il y en a plusieurs, on prend celle qu'on trouve : la principale et seulement celle-là
'''

import os
import pandas as pd
os.chdir(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
from data._1__extract_a_bdnb_table import get_bdnb_table




cols_rnic =[
    'EPCI',
 'Commune',
 "Numéro d'immatriculation",
 "Date d'immatriculation",
 'Date de la dernière MAJ',
 'Type de syndic : bénévole / professionnel / non connu',
 'Identification du représentant légal  (raison sociale et le numéro SIRET du syndic professionnel ou Civilité/prénom/ nom du syndic bénévole ou coopératif)',
 'SIRET du représentant légal',
 'Code APE',
 'Commune du représentant légal',
 'Mandat en cours dans la copropriété',
 'Date de fin du dernier mandat',
 'Nom d’usage de la copropriété',
 'Adresse de référence',
 'Numéro et Voie (adresse de référence)',
 'Code postal (adresse de référence)',
 'Commune (adresse de référence)',
 'Adresse complémentaire 1',
 'Adresse complémentaire 2',
 'Adresse complémentaire 3',
#  "Nombre d'adresses complémentaires",
#  'long',
#  'lat',
 'Date du règlement de copropriété',
 'Résidence service',
 'Syndicat coopératif',
 'Syndicat principal ou syndicat secondaire',
 'Si secondaire, n° d’immatriculation du principal',
#  'Nombre d’ASL auxquelles est rattaché le syndicat de copropriétaires',
#  'Nombre d’AFUL auxquelles est rattaché le syndicat de copropriétaires',
#  'Nombre d’Unions de syndicats auxquelles est rattaché le syndicat de copropriétaires',
 'Nombre total de lots',
 'Nombre total de lots à usage d’habitation, de bureaux ou de commerces',
 'Nombre de lots à usage d’habitation',
 'Nombre de lots de stationnement',
 'Période de construction',
 'Référence Cadastrale 1',
#  'Code INSEE commune 1',
#  'Préfixe 1',
#  'Section 1',
#  'Numéro parcelle 1',
#  'Référence Cadastrale 2',
#  'Code INSEE commune 2',
#  'Préfixe 2',
#  'Section 2',
#  'Numéro parcelle 2',
#  'Référence Cadastrale 3',
#  'Code INSEE commune 3',
#  'Préfixe 3',
#  'Section 3',
#  'Numéro parcelle 3',
 'Nombre de parcelles cadastrales',
#  'nom_qp_2015',
#  'code_qp_2015',
#  'nom_qp_2024',
#  'code_qp_2024',
#  'Copro dans ACV',
#  'Copro dans PVD',
#  'Code de PDP',
#  'Copro dans PDP',
#  'Copro aidée',
#  'Code Officiel Commune',
#  'Nom Officiel Commune',
#  'Code Officiel Arrondissement Commune',
#  'Nom Officiel Arrondissement Commune',
#  'Code Officiel EPCI',
#  'Nom Officiel EPCI',
#  'Code Officiel Département',
#  'Nom Officiel Département',
#  'Code Officiel Région',
#  'Nom Officiel Région'
 ]
rnic = pd.read_csv("/home/alexis/git/BDNB/RNIC/rnc-data-gouv-with-qpv.csv",
                   encoding='utf8', usecols=cols_rnic, nrows=None)
rnic.rename(columns={
    "Identification du représentant légal  (raison sociale et le numéro SIRET du syndic professionnel ou Civilité/prénom/ nom du syndic bénévole ou coopératif)": "Identification",
}, inplace=True)

bdnb_rnic = get_bdnb_table('75', 'batiment_groupe_rnc')
# batiment_groupe_id          bdnb-bg-1H8X-Z12L-2RGS
# numero_immat_principal                   AA2085041
# periode_construction_max                AVANT_1949
# l_annee_construction                    [ "1860" ]
# nb_lot_garpark                                 0.0
# nb_lot_tot                                    62.0
# nb_log                                        32.0
# nb_lot_tertiaire                               8.0
# l_nom_copro                 [ "SDC 8 RUE DROUOT" ]
# l_siret                       [ "39200329900030" ]
# copro_dans_pvd                                   0
bdnb_rnic['numero_immat_principal'].isin(rnic['Numéro d\'immatriculation']).value_counts()
# la plus part des rnic sont dans le bdnb_rnic

voir = bdnb_rnic.merge(rnic, left_on='numero_immat_principal', right_on='Numéro d\'immatriculation')
# la plus part des rnic sont dans le bdnb_rnic
pas_meme = voir['periode_construction_max'] != voir['Période de construction']
voir[pas_meme][['periode_construction_max', 'Période de construction']].value_counts()
# souvent le même maias pas tout le temps (15% des cas)
# peut etre parce qu'on a utiliser un groupe de batiment et pas un batiment


vvoir = voir[['nb_lot_garpark', 'Nombre de lots de stationnement',
       'nb_lot_tot', 'Nombre total de lots',
       'nb_log', 'Nombre total de lots à usage d’habitation, de bureaux ou de commerces',
       'nb_lot_tertiaire', 'Nombre de lots à usage d’hab']]

test = voir['nb_lot_tot'] != voir['Nombre total de lots']
test.value_counts()

test = voir['nb_lot_garpark'] != voir['Nombre de lots de stationnement']
test.value_counts()

test = voir['nb_log'] != voir['Nombre de lots à usage d’habitation']
test.value_counts()
# on a quand même pas mal de différnces
voir.loc[test, ['batiment_groupe_id', 'nb_log', 'Nombre de lots à usage d’habitation']].value_counts()

test = voir['nb_lot_tertiaire'] != ( voir['Nombre total de lots à usage d’habitation, de bureaux ou de commerces'] - voir['Nombre de lots à usage d’habitation'])
test.value_counts()

##################################
# comprendre un cas
un_cas_groupe = bdnb_rnic[bdnb_rnic['batiment_groupe_id'] == 'bdnb-bg-1138-M7VM-2CWW']
un_cas_immat = un_cas_groupe['numero_immat_principal'].iloc[0]
le_cas_rnic =rnic[rnic['Numéro d\'immatriculation'] == un_cas_immat]
var = 'Nom d’usage de la copropriété'
var = 'Numéro et Voie (adresse de référence)'
adresse_du_cas = le_cas_rnic[var].iloc[0]
multi_adresse_pe = rnic[rnic[var] == adresse_du_cas]
multi_adresse_pe

# je n'ai pas trouvé la cohérence entre les adresses
# de bdnb et rnic
42874890900416
32605713000048

rnic[rnic['SIRET du représentant légal'].str.startswith('32605713000', na=False)].iloc[0]
rnic[rnic['SIRET du représentant légal'].str.startswith('32605713000', na=False)]['Date du règlement de copropriété']

sum(rnic[rnic['SIRET du représentant légal'].str.startswith('32605713000', na=False)]['Date du règlement de copropriété'] == '01/01/1971')


Nombre total de lots                                                                                                                                                                              56
Nombre total de lots à usage d’habitation, de bureaux ou de commerces                                                                                                                             56
Nombre de lots à usage d’habitation                                                                                                                                                               49
Nombre de lots de stationnement   
0.0
nb_lot_tot                                                                                                                                                                                      56.0
nb_log                                                                                                                                                                                          49.0
nb_lot_tertiaire                                                                                                                                                                                 7.0


Nombre total de lots                                                                                                                                                                              56
Nombre total de lots à usage d’habitation, de bureaux ou de commerces                                                                                                                             56
Nombre de lots à usage d’habitation    


rnic[rnic['Commune'].str.startswith('75110', na=False)]



#### avec le rnic
craunot_rnic = rnic[rnic['Identification'].str.contains('CRAUNOT', na=False)]
craunot_paris_rnic = craunot_rnic[craunot_rnic['Commune'].str.startswith('75110', na=False)]
craunot_st_denis_rnic = craunot_rnic[craunot_rnic['Adresse de référence'].str.contains('denis', na=False)]
immatriculation = "AC1650431"

bdnb_rnic[bdnb_rnic["numero_immat_principal"] == "AC1650431"].iloc[0]

rnic[rnic['Numéro d\'immatriculation'] == "AC1650431"].iloc[0]

get_bdnb_table()