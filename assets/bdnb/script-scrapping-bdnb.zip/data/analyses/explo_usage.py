
filename = "batiment_groupe_ffo_bat"
with zip_ref.open("csv/" + filename + ".csv") as f:
    foncier = _read_table(f, filename)


filename = "batiment_groupe_synthese_propriete_usage"
with zip_ref.open("csv/" + filename + ".csv") as f:
    synthese_usage = _read_table(f, filename)


filename = "batiment_groupe_bpe"
with zip_ref.open("csv/" + filename + ".csv") as f:
    bpe = _read_table(f, filename)


foncier_plus = foncier.merge(synthese_usage, 
                             on='batiment_groupe_id', how='outer', suffixes=('_foncier', '_synthese_usage'),
                             indicator=True)

foncier_plus[['_merge', 'usage_principal_bdnb_open', 'usage_niveau_1_txt']].value_counts(sort=False, dropna=False)

# _merge      usage_principal_bdnb_open  usage_niveau_1_txt    
# right_only  Indifférencié              NaN                       102938
#             Tertiaire                  NaN                          802
# both        Dépendance                 Dépendance                  6807
#             Résidentiel collectif      Résidentiel collectif       9396
#             Résidentiel individuel     Résidentiel individuel    141905
#             Secondaire                 Secondaire                  1314
#             Tertiaire                  Dépendance                    17
#                                        Résidentiel collectif        382
#                                        Résidentiel individuel       168
#                                        Secondaire                    16
#                                        Tertiaire & Autres          8049
# Name: count, dtype: int64

usage_plus = synthese_usage.merge(bpe,
                                  on='batiment_groupe_id', how='outer', suffixes=('_usage', '_bpe'),
                                  indicator=True)
# on l'a très peu
usage_plus._merge.value_counts()
usage_plus[['usage_principal_bdnb_open', 'l_type_equipement']].value_counts(sort=False, dropna=False)
usage_plus[['usage_principal_bdnb_open', 'l_type_equipement']].value_counts(sort=False, dropna=True)
usage_plus[['usage_principal_bdnb_open', 'l_type_equipement']].value_counts(sort=True, dropna=True).head(20)
usage_plus[['l_type_equipement']].value_counts(sort=T, dropna=True).head(20)


col = bpe['l_type_equipement']
def nettoyage_type_equipement(col):
    col = col.str.strip().str.lower().str.replace('[ "', '').str.replace('" ]', '')
    values = col.str.split('", "').explode()
    values.value_counts()

