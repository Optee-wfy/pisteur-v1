import os
from more_itertools import last
import pandas as pd
os.chdir(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
from data._1__extract_a_bdnb_table import get_bdnb_table

dep = "22"

group = get_bdnb_table(dep, 'batiment_groupe_adresse', brut=False)
