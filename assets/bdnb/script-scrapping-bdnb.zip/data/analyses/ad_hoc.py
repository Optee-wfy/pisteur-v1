import os
import pandas as pd
os.chdir(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
from data._1__extract_a_bdnb_table import get_bdnb_table


bdnb_rnic['l_type_pdl'].value_counts()
bdnb_rnic['l_nom_pdl'].value_counts()
bdnb_rnic['nb_pdl'].value_counts()

departements = [f"{i:02d}" for i in range(1, 96)] + ["2a", "2b"]
departements.remove('20')
for dep in departements:
    bdnb_rnic = get_bdnb_table(dep, 'batiment_groupe_hthd')
    assert bdnb_rnic['l_nom_pdl'].isnull().all(), "Il y a des noms de PDL dans la table batiment_groupe_hthd, ce n'est pas normal !"

