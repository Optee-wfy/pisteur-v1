
import os
import pandas as pd
from requests import get
os.chdir(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
from data._1__extract_a_bdnb_table import get_bdnb_table


dep = "22"

rel = get_bdnb_table(dep, 'rel_batiment_groupe_dpe_logement', brut=True)
dpe = get_bdnb_table(dep, 'dpe_logement')
dpe_groupe = get_bdnb_table(dep, 'batiment_groupe_dpe_representatif_logement', brut=True)
# en fait on va oublier cette table qui est partielle
# et fait juste redite des info de la table dpe_logement
rep = get_bdnb_table(dep, 'batiment_groupe_dpe_representatif_logement')
test = rep.merge(dpe, on='identifiant_dpe', how='left', suffixes=('_rep', '_dpe'),
          indicator=True)
# c'est bien les mêmes
for val in test.columns:
    if val.endswith('_rep') and val != 'epaisseur_structure_mur_exterieur_rep':
        print(f"On vérifie la colonne {val} dans le merge")
        val_dpe = val[:-4] + '_dpe'
        
        if val_dpe in test.columns:
            assert test[val].astype(str).equals(test[val_dpe].astype(str)), f"Les colonnes {val} et {val_dpe} ne sont pas égales dans le merge !"
            diff = test[val].astype(str) != test[val_dpe].astype(str)
            if diff.any():
                print(test[diff][[ val, val_dpe]])
        else:
            print(f"Attention, la colonne {val_dpe} n'existe pas dans le merge, mais {val} est présente.")


test = rel.merge(dpe, on='identifiant_dpe', how='outer', suffixes=('_rep', '_dpe'),
          indicator=True)
# ils sont tous dedans

# il ne reste plus qu'à savoir
# pourquoi on a des bpe qui ne sont pas dans la table batiment_groupe_hthd ?
test = dpe.merge(rep, on='identifiant_dpe', how='left', suffixes=('_rep', '_dpe'),
          indicator=True)


test.groupby('_merge')['annee_construction_dpe_rep'].value_counts()


rel[rel['batiment_groupe_id'] == 'bdnb-bg-NYVA-GE2W-GXEG']
batiment = rel[rel['batiment_groupe_id'] == 'bdnb-bg-NYVA-GE2W-GXEG']
rel[rel['batiment_groupe_id'] == 'bdnb-bg-NYVA-GE2W-GXEG'].iloc[0]
rel[rel['batiment_groupe_id'] == 'bdnb-bg-NYVA-GE2W-GXEG'].iloc[1]

dpe[ dpe['identifiant_dpe'] == batiment['identifiant_dpe'].iloc[0]].iloc[0, :50]
dpe[ dpe['identifiant_dpe'] == batiment['identifiant_dpe'].iloc[1]].iloc[0, :50]

vv0 = dpe[dpe['identifiant_dpe'] == batiment['identifiant_dpe'].iloc[0]].iloc[0]
vv1 = dpe[dpe['identifiant_dpe'] == batiment['identifiant_dpe'].iloc[12]].iloc[0]
vv = vv1 == vv0
vv[vv1.notnull()]