### on part sur l'étude des des copros finalement
filename = "sitadel"
with zip_ref.open("csv/" + filename + ".csv") as f:
    sitadel = _read_table(f, filename)

filename = "parcelle_sitadel"
with zip_ref.open("csv/" + filename + ".csv") as f:
    parcelle_sitadel = _read_table(f, filename)