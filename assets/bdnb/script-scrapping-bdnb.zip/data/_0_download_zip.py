import os
# os.chdir("/home/alexis/git/bdnb")
print("Current working directory:", os.getcwd())
import requests

path_data = r"/home/alexis/git/BDNB"

def __download_zip_dep_bdnb(id_dep):
    ####### downloaad the tar.gz file from the URL
    url_dep = r"https://open-data.s3.fr-par.scw.cloud/bdnb_millesime_2024-10-a/millesime_2024-10-a_dep{id_dep}/open_data_millesime_2024-10-a_dep{id_dep}_csv.zip".format(id_dep=id_dep)
    response = requests.get(url_dep, stream=True)
    with open(os.path.join(path_data, "BDNB", "zip", '2024-10-a_dep{id_dep}_csv.zip'.format(id_dep=id_dep)), 'wb') as f:
        for chunk in response.iter_content(chunk_size=8192):
            if chunk:
                f.write(chunk)

# Loop over French department numbers (01 to 95, plus 2A, 2B, and overseas)
departements = [f"{i:02d}" for i in range(1, 96)] + ["2a", "2b"]
departements.remove('20')
for dep in departements:
    __download_zip_dep_bdnb(dep)