#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jul 22 16:55:04 2025

@author: alexis
"""

# https://echanges.dila.gouv.fr/OPENDATA/Base_donn%c3%83%c2%a9es_locales/DILA_Specifications-datagouv-base-de-donnees-locales-Service-public_V1.4_20250404.pdf

# -*- coding: utf-8 -*-

import os
import pandas as pd


# https://api-lannuaire.service-public.fr/explore/dataset/api-lannuaire-administration/information/?refine.categorie=SI

path = "/home/alexis/git/BDNB/AnnuairePublic"

tab = pd.read_csv(os.path.join(path, "api-lannuaire-administration.csv"),
                  sep=";")

tab.siren.isnull().value_counts()
tab.siret.isnull().value_counts()
mauvais_siren = tab['siren'].str[3].str.contains(' ') | tab['siren'].str.contains(',')
tab.loc[mauvais_siren, 'siren'] = pd.NA
tab.loc[tab['siren'].isnull(), 'siren'] = tab.loc[tab['siren'].isnull(), 'siret'].str.replace(' ', '').str[:9]
tab.loc[:, 'siren'] = tab['siren'].fillna(-1).astype(int).astype(str)


avec_contact = tab['telephone'].notnull() | tab['adresse_courriel'].notnull()
avec_contact.value_counts()

# pour filtrer mais finalement on a type_organisme qui peut le faire
# not_ambassade = ~tab['adresse_courriel'].str.contains('diplomatie') & ~tab['nom'].str.contains('mbassase') 

is_utile = tab['siren'] != '-1' & avec_contact
tab_utiles = tab[is_utile]

cols_utiles = ['nom', 'siren', 'siret', 'telephone', 'adresse_courriel', 'type_organisme']

# petits nettoyages
tab['telephone'] = tab['telephone'].str.replace(', "description": ""}', '}')
avec_description = tab['telephone'].str.contains('descr')
tab.loc[avec_description.fillna(False), 'telephone']
# on retire quand on a trop d'entrée pour un même siren
# quand on en a peu on excusera l'erreur et on saura réorienter 
# mairie déléguée au lieu de mairie 
# quand ily en a beaucoup on pardonnera moins
vc = tab.siren.value_counts() 
vc[vc <= 2]

tab_utiles = tab_utiles[tab_utiles['siren'].isin(vc[vc <= 2].index)]

tab_utiles[cols_utiles].to_csv(os.path.join(path, "contact_admin.csv"), index=False)

# catégorie 
# Précise la typologie du service : service institutionnel, service institutionnel local, service local.