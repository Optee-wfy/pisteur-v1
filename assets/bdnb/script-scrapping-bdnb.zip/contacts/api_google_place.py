import requests


''' cf here pour les tarifs 

https://developers.google.com/maps/billing-and-pricing/pricing?hl=fr

'''


def search_google_places_by_text(query, location_bias=None):
    """
    Calls the Google Places API (v1) to search for places by text.
    Returns the JSON response if successful, or None if an error occurs.
    """
    url = "https://places.googleapis.com/v1/places:searchText"
    headers = {
        "Content-Type": "application/json",
        "X-Goog-Api-Key": api_key,
        "X-Goog-FieldMask": ",".join([
            "places.displayName",
            "places.formattedAddress",
            "places.internationalPhoneNumber",
            "places.nationalPhoneNumber",
            "places.websiteUri"])
    }

    payload = {
        "textQuery": query
    }
    if location_bias:
        payload["locationBias"] = location_bias

    try:
        response = requests.post(url, headers=headers, json=payload, timeout=10)
        response.raise_for_status()
        data = response.json()
        return data
    except requests.RequestException as e:
        print(f"Request failed: {e}")
        return None


if __name__ == "__main__":
    query = "Eiffel Tower"
    query = "SDC LE CLARION SUITES"
    location_bias = "point:48.8588443,2.2943506"
    result = search_google_places_by_text(query, location_bias)
    print(result)
